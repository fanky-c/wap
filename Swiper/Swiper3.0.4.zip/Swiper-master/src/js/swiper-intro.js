/*===========================
Swiper
===========================*/
window.Swiper = function (container, params) {